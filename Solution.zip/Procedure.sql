DROP PROCEDURE IF EXISTS create_shedule;


DELIMITER // 
CREATE PROCEDURE `create_shedule` (IN start date, IN end date) 
LANGUAGE SQL 
DETERMINISTIC 
SQL SECURITY DEFINER 
COMMENT 'A procedure' 
BEGIN 
	DECLARE b INT;
    DECLARE id_name INT; 
    DECLARE shedule VARCHAR(25);
    DECLARE date_bagin DATETIME; 
    DECLARE date_end DATETIME;
    DECLARE name_ VARCHAR(25); 
    DECLARE len_shedule INT; 
    DECLARE new_end DATETIME; 
    DECLARE offset_ INT;
    DECLARE new_start DATETIME; 
    DECLARE days_actual INT;
    DECLARE i INT;
    DECLARE smena VARCHAR(25);
    DECLARE start_smena DATETIME;
    DECLARE end_smena DATETIME;
    
	DECLARE cur1 CURSOR FOR SELECT
		t.*,
		DATEDIFF(t.NEW_END, t.NEW_START) as DAYS_ACTUAL
	FROM
	(SELECT
		t_contractor_sheruler.*,
		supplier.NAME,
		length(t_contractor_sheruler.shedule) / 2 as LEN_SHEDULE,
		LEAST(end, DATE_ADD(t_contractor_sheruler.DATE_END, INTERVAL 1 DAY)) as NEW_END,
		GREATEST(DATEDIFF(start, t_contractor_sheruler.DATE_BEGIN), 0) % (length(t_contractor_sheruler.shedule) / 2) as OFFSET_,
		GREATEST(t_contractor_sheruler.DATE_BEGIN, start) as NEW_START
	FROM 
		t_contractor_sheruler LEFT JOIN supplier ON t_contractor_sheruler.ID_NAME=supplier.ID_NAME) as t;
	
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET b = 1;
    OPEN cur1;
    SET b = 0; 
    WHILE b = 0 DO
		FETCH cur1 INTO id_name, shedule, date_bagin, date_end, name_, len_shedule, new_end, offset_, new_start, days_actual;
            IF days_actual > 0 THEN 
				SET i = 0;
                WHILE i < days_actual DO
					set smena = MID(shedule, (i + offset_) % len_shedule, 1);
                    IF smena = 'д' THEN
						SET start_smena = DATE_ADD(new_start, INTERVAL 8 + i * 24 HOUR);
                        SET end_smena = DATE_ADD(start_smena, INTERVAL 12 HOUR);
                    END IF;
                    
					IF smena = 'н' THEN
						SET start_smena = DATE_ADD(new_start, INTERVAL 20 + i * 24 HOUR);
                        SET end_smena = DATE_ADD(start_smena, INTERVAL 12 HOUR);
                    END IF;
                    
					IF smena = 'с' THEN
						SET start_smena = DATE_ADD(new_start, INTERVAL 8 + i * 24 HOUR);
                        SET end_smena = DATE_ADD(start_smena, INTERVAL 24 HOUR);
                    END IF;
                    
					IF smena <> 'в' THEN
						INSERT T_CONTRACTOR_WORK_DAY(`NAME`, DATE_BEGIN, DATE_END) VALUES (name_, start_smena, end_smena);
                    END IF;
                    
                    set i = i + 1;
				END WHILE;
            END IF;

	END WHILE; 
	CLOSE cur1;
END// 

CALL create_shedule(STR_TO_DATE('2019-01-03', '%Y-%m-%d') , STR_TO_DATE('2019-03-02', '%Y-%m-%d'));

