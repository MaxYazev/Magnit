/*Сделать выборку содержащую сколько рабочих дней было у каждого поставщика*/
SELECT 
  NAME, count(*)
FROM
  t_contractor_work_day
GROUP BY
  NAME
  
/*Сделать выборку поставщиков, у которыйх было больше 10 рабочих дней за январь 2019 года*/
SELECT 
  NAME
FROM
  t_contractor_work_day
WHERE
  (MONTH(DATE_BEGIN)=1 or MONTH(DATE_END)=1) and (YEAR(DATE_BEGIN)=2019 or YEAR(DATE_END)=2019)
GROUP BY
  NAME
HAVING
  COUNT(*) > 10
  
/*Сделать выборку поставщиков, кто работал 14, 15 и 16 января 2019 года*/  
SELECT 
  NAME
FROM
  t_contractor_work_day
WHERE
  ((MONTH(DATE_BEGIN)=1 or MONTH(DATE_END)=1) and (YEAR(DATE_BEGIN)=2019 or YEAR(DATE_END)=2019)
  or (MONTH(DATE_END)=1 or MONTH(DATE_END)=1) and (YEAR(DATE_END)=2019 or YEAR(DATE_END)=2019))
  and ((DAY(DATE_BEGIN)=14 or DAY(DATE_BEGIN)=15 or DAY(DATE_BEGIN)=16) or (DAY(DATE_END)=14 or DAY(DATE_END)=15 or DAY(DATE_END)=16))
GROUP BY
  NAME
HAVING
  COUNT(*)=3
  
  